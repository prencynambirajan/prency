import java.io.*;
import java.net.*;
class arpc
{
public static void main(String a[])throws Exception
{
Socket s=new Socket("localhost",5555);
DataInputStream dis=new DataInputStream(s.getInputStream());
DataOutputStream dos=new DataOutputStream(s.getOutputStream());
String ip[]={"172.16.5.39","172.16.5.40","172.16.5.41","172.16.5.42"};
String mac[]={"01-10-B5-F2-EF-39","01-10-B5-F2-EF-40","01-10-B5-F2-EF-41","01-10-B5-F2-EF-42"};
String str=dis.readLine();
System.out.println("IP address received from server"+str);
int flag=0;
for(int i=0;i<5;i++)
{
if(str.equals(ip[i])==true)
{
flag=1;
String str1=mac[i];
dos.writeBytes(str1+"\n");
break;
}
}
if(flag==0)
System.out.println("Given IP address is not in this network");
s.close();
}
}