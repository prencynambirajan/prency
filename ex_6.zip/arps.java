import java.io.*;
import java.net.*;
class arps
{
public static void main(String a[])throws Exception
{
ServerSocket ss=new ServerSocket(5555);
Socket s=ss.accept();
DataInputStream dis=new DataInputStream(s.getInputStream());
DataOutputStream dos=new DataOutputStream(s.getOutputStream());
DataInputStream in=new DataInputStream(System.in);
System.out.println("Enter the Ip address");
String str=in.readLine();
dos.writeBytes(str+"\n");
System.out.println("The corresponding MAC address is"+dis.readLine());
}
}