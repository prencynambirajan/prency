#!"C:\xampp\perl\bin\perl.exe"
print "content-type:text/html\n";
use CGI qw(:standard);
print(header());

print "<center>array of numbers in decending order:<br>";
print "\n";
 
@numbers1 = (19, 45, 27, 11, 28);
@sorted_numbers1 = sort @numbers1;
foreach (@sorted_numbers1) {
   print $_;
   print "\n";
}

print "<br><br>array of string in descending order:<br>";
print "\n";

@letters1 = ('dog', 'cat', 'bird', 'fox', 'ox');
@sorted_letters1 = sort @letters1;
foreach (@sorted_letters1) {
   print $_;
   print "\n";
}

 print "<br><br>reversed array of numbers:<br> ";
print "\n";

@numbers2 = (1, 2, 3, 4, 5);
@reversed_numbers2 = reverse @numbers2;
foreach (@reversed_numbers2) {
   print $_;
   print "\n";
}

 print "<br><br>reversed array of string:<br>";
print "\n";

@letters2 = ('first', 'second', 'third', 'fourth', 'fifth');
@reversed_letters2 = reverse @letters2;
foreach (@reversed_letters2) {
   print $_;
   print "\n";
}


  print(end_html());
