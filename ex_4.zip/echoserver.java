import java.io.*;
import java.net.*;
import java.lang.String;
public class echoserver
{
public static void main(String a[])throws IOException
{
ServerSocket ss=new ServerSocket(55555);
Socket s=ss.accept();
DataInputStream dis=new DataInputStream(s.getInputStream());
DataOutputStream dos=new DataOutputStream(s.getOutputStream());
String str;
System.out.println("\n Server Side \n");
while(true)
{
str=dis.readLine();
dos.writeBytes(str +"\n");
System.out.println("Message from clinet \n");
System.out.println(str +"\n");
}
}
}