import java.io.*;
import java.net.*;
public class talkc
{
public static void main(String a[])throws Exception
{
DataInputStream inp=new DataInputStream(System.in);
Socket s=new Socket(InetAddress.getLocalHost(),5555);
DataInputStream dis=new DataInputStream(s.getInputStream());
DataOutputStream dos=new DataOutputStream(s.getOutputStream());
String str;
System.out.println("CLIENT\n");
System.out.println("Enter the message\n");
while((str=inp.readLine())!=null)
{
dos.writeBytes(str);
dos.writeBytes("\n");
if(str.equals("exit"))
{
System.out.println("Client Terminated\n");
break;
}
else
{
System.out.println("Reply\n");
System.out.println(dis.readLine());
System.out.println("Enter the client side message\n");
}
}
s.close();
}
}