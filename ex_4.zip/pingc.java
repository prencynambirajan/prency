import java.io.*;
import java.net.*;
import java.util.*;
class pingc
{
public static void main(String a[])throws Exception
{
String str;
int c=0;
long t1,t2;
Socket s=new Socket("localhost",5555);
DataInputStream dis=new DataInputStream(s.getInputStream());
PrintStream out=new PrintStream(s.getOutputStream());
while(c<4)
{
t1=System.currentTimeMillis();
str="welcome to network programming world";
System.out.println(str);
System.out.println(dis.readLine());
t2=System.currentTimeMillis();
System.out.println(";TTL="+(t2-t1)+"ms");
c++;
}
s.close();
}
}