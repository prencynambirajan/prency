import java.io.*;
import java.net.*;
import java.lang.String;
public class echoclient
{
public static void main(String a[])throws IOException
{
DataInputStream dis=new DataInputStream(System.in);
Socket s=new Socket("localhost",55555);
DataInputStream inp=new DataInputStream(s.getInputStream());
DataOutputStream dos=new DataOutputStream(s.getOutputStream());
String str;
System.out.println("Client side \n");
System.out.println("Type exit to quit\n");
System.out.println("Enter the message\n");
while((str=dis.readLine())!=null)
{
dos.writeBytes(str+"\n");
if(str.equals("exit"))
{
dos.writeBytes("Client terminated\n");
break;
}
else
{
System.out.println("Echo from Server\n");
System.out.println(inp.readLine());
System.out.println("Enter the message\n");
}
}
}
}