import java.io.*;
import java.net.*;
import java.util.*;
import java.text.*;
class pings
{
public static void main(String a[])throws Exception
{
ServerSocket ss=new ServerSocket(55555);
Socket s=ss.accept();
int c=0;
while(c<4)
{
DataInputStream dis=new DataInputStream(s.getInputStream());
PrintStream out=new PrintStream(s.getOutputStream());
String str=dis.readLine();
out.println("reply "+s.getInetAddress()+";Length"+str.length());
c++;
}
}
}