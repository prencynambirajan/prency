import  java.io.*;
import java.net.*;
public class talks
{
public static void main(String a[])throws Exception
{
DataInputStream inp=new DataInputStream(System.in);
ServerSocket ss=new ServerSocket(55555);
Socket s=ss.accept();
DataInputStream dis=new DataInputStream(s.getInputStream());
DataOutputStream dos=new DataOutputStream(s.getOutputStream());
String str;
System.out.println("SERVER\n");
while(true)
{
System.out.println("MESSAGE FROM CLIENT\n");
String str1=dis.readLine();
if(str1.equals("exit"))
{
System.out.println("exit");
break;
}
else
{
System.out.println(str1+"");
System.out.println("Enter the server side message\n");
str=inp.readLine();
dos.writeBytes(str);
dos.writeBytes("\n");
}}}}