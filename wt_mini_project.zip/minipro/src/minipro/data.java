package minipro;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.eclipse.jdt.internal.compiler.ast.Statement;

/**
 * Servlet implementation class sisu
 */
public class data extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public data() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		PrintWriter pw=res.getWriter();
		  res.setContentType("text/html");  
		  pw.println("<html>");
		  pw.println("<head>");
		  pw.println("<style>");
		  pw.println("body {    background-image: url(trainimg/w1.jpg);   background-repeat: no-repeat;    background-size: cover; }");
		  pw.println("</style>");
		  pw.println("</head>");
		  pw.println("<body>");
		  pw.println("<center style=\"color:blue\">");
		  String tb=req.getParameter("tab");    
		  try
		  {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		    Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","SYSTEM","prency");
          //System.out.println("test");
		    // Statement st=(Statement) con.createStatement();
		    int sel=Integer.parseInt(req.getParameter("choice"));                  
			switch(sel)
			{ 
			case 1://Insert a row
				{String namea=req.getParameter("name1");
				String agea=req.getParameter("age");
				String doba=req.getParameter("dob");
				String gendera=req.getParameter("gender");				
				String contacta=req.getParameter("contact");
				String addressa=req.getParameter("address");
				int tnoa=Integer.parseInt(req.getParameter("num1"));
				int pnoa=Integer.parseInt(req.getParameter("person1"));				
				PreparedStatement pi=con.prepareStatement("insert into "+tb+" values(?,?,?,?,?,?,?,?)");  				 
				pi.setString(1,namea);  
				pi.setString(2,agea);
				pi.setString(3,doba);  
				pi.setString(4,gendera);
				pi.setString(5,contacta);  
				pi.setString(6,addressa);				
				pi.setInt(7,tnoa); 
				pi.setInt(8,pnoa); 
				pi.executeUpdate();  
				pw.print("<h1>You are successfully booked ticket...<h1>");  
				pw.print("<h1>Table data after insertion..<h1>");  
				pi=con.prepareStatement("select * from "+tb); 
				ResultSet rs=pi.executeQuery("Select * from "+tb);
		        pw.println("<table border=1>");
				pw.println("<tr><th>Name</th><th>Age</th><th>DOB</th><th>Gender</th><th>Contact</th><th>Address</th><th>TrainNo</th><th>No:persons</th></tr>");
		        while(rs.next())
		         {
		           pw.println("<tr><td>"+rs.getString(1)+"</td><td>"+rs.getString(2)+"</td><td>"+rs.getString(3)+"</td><td>"+rs.getString(4)+"</td><td>"+rs.getString(5)+"</td><td>"+rs.getString(6)+"</td><td>"+rs.getInt(7)+"</td><td>"+rs.getInt(8)+"</td></tr>");
		         }
		        pw.println("</table>");
			}
			break;
					
			case 2: //Select a row
			{ String nameb=req.getParameter("name2");
			  if(nameb.equals("999"))
			  { PreparedStatement pss=con.prepareStatement("select * from "+tb);
			    ResultSet rs=pss.executeQuery();
			    pw.print("<h1>Table for viewing..<h1>");
			    pw.println("<table border=1>");
			    pw.println("<tr><th>Name</th><th>Age</th><th>DOB</th><th>Gender</th><th>Contact</th><th>Address</th><th>TrainNo</th><th>No:persons</th></tr>");
				while(rs.next())
				{
					pw.println("<tr><td>"+rs.getString(1)+"</td><td>"+rs.getString(2)+"</td><td>"+rs.getString(3)+"</td><td>"+rs.getString(4)+"</td><td>"+rs.getString(5)+"</td><td>"+rs.getString(6)+"</td><td>"+rs.getInt(7)+"</td><td>"+rs.getInt(8)+"</td></tr>");
		        }
				pw.println("</table>");
			  }
			  else
			 {
				PreparedStatement ps=con.prepareStatement("select * from "+tb+" where name=?");
				ps.setString(1,nameb);
				ResultSet rs=ps.executeQuery();
				pw.print("<h1>Table for viewing..<h1>");
		        pw.println("<table border=1>");
				//pw.println("<h1>Employee details:R.No greater than 100</h1>");
				pw.println("<tr><th>Name</th><th>Age</th><th>DOB</th><th>Gender</th><th>Contact</th><th>Address</th><th>TrainNo</th><th>No:persons</th></tr>");
		        while(rs.next())
		        {
		           pw.println("<tr><td>"+rs.getString(1)+"</td><td>"+rs.getString(2)+"</td><td>"+rs.getString(3)+"</td><td>"+rs.getString(4)+"</td><td>"+rs.getString(5)+"</td><td>"+rs.getString(6)+"</td><td>"+rs.getInt(7)+"</td><td>"+rs.getInt(8)+"</td></tr>");
		        }
		       pw.println("</table>");
			 }
		   }
		  break;
					
		  case 3: //Update rows
			{		
				int personc=Integer.parseInt(req.getParameter("person2"));				
				String namec=req.getParameter("name3");
				int numc=Integer.parseInt(req.getParameter("num2"));
				PreparedStatement pu=con.prepareStatement("update "+tb+" set  person=? , no=? where name=?");
			pu.setInt(1,numc);  
			pu.setInt(2,personc); 
			pu.setString(3,namec); 
			pu.executeUpdate();
			pu=con.prepareStatement("select * from "+tb); 
		    ResultSet rs=pu.executeQuery();
			pw.print("<h1>Table data after Update..<h1>");  
			pw.println("<table border=1>");
			pw.println("<tr><th>Name</th><th>Age</th><th>DOB</th><th>Gender</th><th>Contact</th><th>Address</th><th>TrainNo</th><th>No:persons</th></tr>");
			while(rs.next())
		    {
			pw.println("<tr><td>"+rs.getString(1)+"</td><td>"+rs.getString(2)+"</td><td>"+rs.getString(3)+"</td><td>"+rs.getString(4)+"</td><td>"+rs.getString(5)+"</td><td>"+rs.getString(6)+"</td><td>"+rs.getInt(7)+"</td><td>"+rs.getInt(8)+"</td></tr>");
		    }
		    pw.println("</table>");
			}
		    
			break;      

			case 4: //Delete rows
			{
				String named=req.getParameter("name4");
			PreparedStatement pd=con.prepareStatement("delete from "+tb+" where name=?");
			pd.setString(1,named);  
			pd.executeUpdate();
			pd=con.prepareStatement("select * from "+tb); 
		    ResultSet rs=pd.executeQuery();
		    pw.print("<h1>Table data after delete..<h1>");  
			pw.println("<table border=1>");
			pw.println("<tr><th>Name</th><th>Age</th><th>DOB</th><th>Gender</th><th>Contact</th><th>Address</th><th>TrainNo</th><th>No:persons</th></tr>");
			while(rs.next())
		    {
			pw.println("<tr><td>"+rs.getString(1)+"</td><td>"+rs.getString(2)+"</td><td>"+rs.getString(3)+"</td><td>"+rs.getString(4)+"</td><td>"+rs.getString(5)+"</td><td>"+rs.getString(6)+"</td><td>"+rs.getInt(7)+"</td><td>"+rs.getInt(8)+"</td></tr>");
		    }
		     pw.println("</table>");
		   }
		   break;
		   		  }
			pw.println("</center>");
			  
			  pw.println("</body>");
			pw.println("</html>");
		  pw.close();
		 }
		 catch (Exception e)
		   {  e.printStackTrace();    }


	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
