package lab;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.eclipse.jdt.internal.compiler.ast.Statement;

/**
 * Servlet implementation class sisu
 */
public class server extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public server() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		PrintWriter pw=res.getWriter();
		  res.setContentType("text/html");        
		  String tb=req.getParameter("t");    
		  try
		  {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		    Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","SYSTEM","prency");
          //System.out.println("test");
		    // Statement st=(Statement) con.createStatement();
		    int sel=Integer.parseInt(req.getParameter("t1"));                  
			switch(sel)
			{ 
			case 1://Insert a row
				{int rno=Integer.parseInt(req.getParameter("t2"));
				String na=req.getParameter("t3");
				String cou=req.getParameter("t4");
				PreparedStatement pi=con.prepareStatement("insert into "+tb+" values(?,?,?)");  
				pi.setInt(1,rno);  
				pi.setString(2,na);  
				pi.setString(3,cou);  
				pi.executeUpdate();  
				pw.print("<h1>You are successfully Inserted a row...<h1>");  
				pw.print("<h1>Table data after insertion..<h1>");  
				pi=con.prepareStatement("select * from "+tb); 
				ResultSet rs=pi.executeQuery("Select * from "+tb);
		        pw.println("<table border=1>");
				pw.println("<tr><th>R.NO</th><th>Name</th><th>Course</th></tr>");
		        while(rs.next())
		         {
		           pw.println("<tr><td>"+rs.getInt(1)+"</td><td>"+rs.getString(2)+
											"</td><td>"+rs.getString(3)+"</td></tr>");
		         }
		        pw.println("</table>");
			}
			break;
					
			case 2: //Select a row
			{ int srno=Integer.parseInt(req.getParameter("t5"));
			  if(srno==999)
			  { PreparedStatement pss=con.prepareStatement("select * from "+tb);
			    ResultSet rs=pss.executeQuery();
			    pw.println("<table border=1>");
			    pw.println("<tr><th>R.NO</th><th>Name</th><th>course</th></tr>");
				while(rs.next())
				{
					pw.println("<tr><td>"+rs.getInt(1)+"</td><td>"+rs.getString(2)
										+"</td><td>"+rs.getString(3)+"</td></tr>");
		        }
				pw.println("</table>");
			  }
			  else if(srno==777)
				 {
					PreparedStatement ps=con.prepareStatement("select * from "+tb+" where course='java'");
					//ps.setInt(1,srno);
					//ps.execute();
					ResultSet rs=ps.executeQuery();
			        pw.println("<table border=1>");
					//pw.println("<h1>Employee details:R.No greater than 100</h1>");
					pw.println("<tr><th>R.NO</th><th>Name</th><th>course</th></tr>");
			        while(rs.next())
			        {
			           pw.println("<tr><td>"+rs.getInt(1)+"</td><td>"+rs.getString(2)+
												"</td><td>"+rs.getString(3)+"</td></tr>");
			        }
			       pw.println("</table>");
				 }

			  else
			 {
				PreparedStatement ps=con.prepareStatement("select * from "+tb+" where no=?");
				ps.setInt(1,srno);
				ps.execute();
				ResultSet rs=ps.executeQuery();
		        pw.println("<table border=1>");
				//pw.println("<h1>Employee details:R.No greater than 100</h1>");
				pw.println("<tr><th>R.NO</th><th>Name</th><th>course</th></tr>");
		        while(rs.next())
		        {
		           pw.println("<tr><td>"+rs.getInt(1)+"</td><td>"+rs.getString(2)+
											"</td><td>"+rs.getString(3)+"</td></tr>");
		        }
		       pw.println("</table>");
			 }
		   }
		  break;
					
		  case 3: //Update rows
			{		
				int urno=Integer.parseInt(req.getParameter("t6"));
				String ucou=req.getParameter("t7");
					PreparedStatement pu=con.prepareStatement("update "+tb+" set  course=? where no=?");
			pu.setString(1,ucou);  
			pu.setInt(2,urno);  
			pu.executeUpdate();
			pu=con.prepareStatement("select * from "+tb); 
		    ResultSet rs=pu.executeQuery();
			pw.print("<h1>Table data after Update..<h1>");  
			pw.println("<table border=1>");
			pw.println("<tr><th>R.NO</th><th>Name</th><th>course</th></tr>");
			while(rs.next())
		    {
			pw.println("<tr><td>"+rs.getInt(1)+"</td><td>"+rs.getString(2)+"</td><td>"
													+rs.getString(3)+"</td></tr>");
		    }
		    pw.println("</table>");
			}
		    
			break;      

			case 4: //Delete rows
			{
			int drno=Integer.parseInt(req.getParameter("t8"));
			PreparedStatement pd=con.prepareStatement("delete from "+tb+" where no=?");
			pd.setInt(1,drno);  
			pd.executeUpdate();
			pd=con.prepareStatement("select * from "+tb); 
		    ResultSet rs=pd.executeQuery();
		    pw.print("<h1>Table data after delete..<h1>");  
			pw.println("<table border=1>");
			pw.println("<tr><th>R.NO</th><th>Name</th><th>course</th></tr>");
			while(rs.next())
		    {
			pw.println("<tr><td>"+rs.getInt(1)+"</td><td>"+rs.getString(2)+
										"</td><td>"+rs.getString(3)+"</td></tr>");
		    }
		     pw.println("</table>");
		   }
		   break;                       
		  }
		  pw.close();
		 }
		 catch (Exception e)
		   {  e.printStackTrace();    }


	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
